import { Component, OnInit } from '@angular/core';
import { INR2USD} from './inr2-usd';
import {Observable} from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {CConversion} from './cconversion';
import {Injectable} from '@angular/core';


@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})

@Injectable()
export class CurrencyComponent implements OnInit {
  inr2usd: INR2USD;
  sFrom: String;
  sTo: String;
  cConvert: CConversion;
  constructor(private http: HttpClient) {
    this.http = http;
    this.inr2usd = new INR2USD(['INR', 'USD'], ['USD', 'INR']);
    this.inr2usd.rate = '70.8';
  }

  ngOnInit() {
  }
  Convert() {
    this.getRate().subscribe(data => {
    this.cConvert = data;
    });
    this.inr2usd.rate = this.cConvert.calcAmount;
  }
public getRate(): Observable<CConversion> {

  return this.http.get<CConversion>('https://curr-conversion.cfapps.io/currency-converter-feign/from/USD/to/INR/quantity/1');
}
}
