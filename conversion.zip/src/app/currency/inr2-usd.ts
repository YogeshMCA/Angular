export class INR2USD {
  fromCodeLst: String[];
  toCodeLst: String[];
  rate: String;
constructor(from: String[], to: String[]) {
    this.fromCodeLst = from;
    this.toCodeLst = to;

 }
}
