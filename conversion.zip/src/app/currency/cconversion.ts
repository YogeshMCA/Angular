export class CConversion {
  id: String;
  from: String;
  to: String;
  quantity: String;
  conversionMultiple: String;
  calcAmount: String;
  port: String;
}



